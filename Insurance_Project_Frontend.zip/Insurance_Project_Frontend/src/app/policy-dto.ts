export class PolicyDto {
    name: string;
    description: string;
    basePremium: number;
    addOns: string;
}
