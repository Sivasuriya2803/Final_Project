export class ProposalStatus {
    proposalId: number;
    userId: number;
    status: string;
    submittedAt: string;
    quoteGeneratedAt: string;
}
