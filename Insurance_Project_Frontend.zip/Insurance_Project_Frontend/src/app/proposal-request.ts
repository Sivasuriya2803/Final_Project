export class ProposalRequest {
  userId: number;
  vehicleType: 'CAR' | 'TRUCK' | 'MOTORCYCLE' | 'CAMPER_VAN';
  policyId: number;
}
