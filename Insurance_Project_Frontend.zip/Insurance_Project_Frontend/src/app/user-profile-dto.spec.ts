import { UserProfileDto } from './user-profile-dto';

describe('UserProfileDto', () => {
  it('should create an instance', () => {
    expect(new UserProfileDto()).toBeTruthy();
  });
});
