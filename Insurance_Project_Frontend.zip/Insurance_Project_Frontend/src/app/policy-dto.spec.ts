import { PolicyDto } from './policy-dto';

describe('PolicyDto', () => {
  it('should create an instance', () => {
    expect(new PolicyDto()).toBeTruthy();
  });
});
