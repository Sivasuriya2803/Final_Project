import { ProposalStatus } from './proposal-status';

describe('ProposalStatus', () => {
  it('should create an instance', () => {
    expect(new ProposalStatus()).toBeTruthy();
  });
});
