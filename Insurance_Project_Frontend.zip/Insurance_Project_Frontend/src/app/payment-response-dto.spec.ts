import { PaymentResponseDto } from './payment-response-dto';

describe('PaymentResponseDto', () => {
  it('should create an instance', () => {
    expect(new PaymentResponseDto()).toBeTruthy();
  });
});
