import { ProposalRequest } from './proposal-request';

describe('ProposalRequest', () => {
  it('should create an instance', () => {
    expect(new ProposalRequest()).toBeTruthy();
  });
});
