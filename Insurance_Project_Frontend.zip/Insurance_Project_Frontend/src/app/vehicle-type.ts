export enum VehicleType {
    CAR = 'CAR',
  TRUCK = 'TRUCK',
  MOTORCYCLE = 'MOTORCYCLE',
  CAMPER_VAN = 'CAMPER_VAN'
}
