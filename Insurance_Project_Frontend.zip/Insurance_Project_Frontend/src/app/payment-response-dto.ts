export class PaymentResponseDto {
    paymentId: number;
    proposalId: number;
    paymentAmount: number;
    paymentDate: string;
    paymentStatus: string;
}
