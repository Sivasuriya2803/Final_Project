export class UserProfileDto {
    id: number;
    username: string;
    email: string;
    name: string;
    address: string;
    dob: string;
    aadhaarNumber: string;
    panNumber: string;
}
